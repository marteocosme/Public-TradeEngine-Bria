# Phase 6 Checklist Runner — Excel / Power BI Template

**Last Updated:** 2026-05-19 (UTC+8)

This template shows how to implement the Phase 6 Data Quality Checks using Excel Power Query or Power BI.

## A) Data Model (recommended)
Load these CSVs as separate tables:
- MM_Snapshots (from *_MM_Snapshots.csv)
- MM_Events (from *_MM_Events.csv)
- MM_Cycle_Summary (from *_MM_Cycle_Summary.csv)

### Relationships
1) MM_Snapshots[correlation_id] → MM_Events[correlation_id] (Many-to-Many; use bridge if needed)
2) MM_Events[cycle_id] → MM_Cycle_Summary[cycle_id] (Many-to-One)

Notes:
- CLOSE is Event-only; do not expect snapshot pairs for CLOSE.
- Snapshot pairs are within MM_Snapshots via correlation_id + record_type.

## B) Power Query — recommended transformations
### B.1 Normalize types
- Parse datetime strings into datetime
- Ensure numeric fields are numeric
- Ensure empty strings are preserved for string N/A

### B.2 Create Snapshot Pair counts
Create a grouped query:
- Group by correlation_id
- Add:
  - before_count = count rows where record_type = MM_SNAPSHOT_BEFORE
  - after_count  = count rows where record_type = MM_SNAPSHOT_AFTER

### B.3 Create Cycle CLOSE count
- Filter Events where event_type = MM_EVENT_CLOSE
- Group by cycle_id and compute close_count

## C) DAX / Visual patterns (starter)
### C.1 Snapshot Pairing
- JF-SNAP-01: correlation_id where before_count=1 and after_count=0
- JF-SNAP-02: correlation_id where before_count=0 and after_count=1
- JF-SNAP-03: correlation_id where before_count!=1 or after_count!=1

### C.2 BEFORE outcome neutrality
Create a boolean column (Power Query preferred):
- before_outcome_violation = record_type=BEFORE and (action_executed<>false OR execution_reason<>"" OR previous_stoploss<>0 OR new_stoploss<>0 OR closed_lots<>0 OR event_outcome<>"")

### C.3 Snapshot success but missing Event (non-CLOSE)
- Create a distinct list of correlation_id from Events excluding CLOSE.
- Flag Snapshot AFTER success rows whose correlation_id is not in that list.

### C.4 Cycle Summary ↔ Event CLOSE reconciliation
- Create Event_CLOSE table (Event rows where event_type=CLOSE) one per cycle_id.
- Join Cycle Summary to Event_CLOSE on cycle_id and compute mismatch flags:
  - exit_time mismatch (summary.exit_time vs event_close.event_time)
  - exit_price mismatch (summary.exit_price vs event_close.close_price)
  - close_reason mismatch
  - deal_id mismatch
  - ticket mismatch
  - position_type mismatch

### C.5 PnL and Volume aggregation
Prefer Power Query:
- Build Event_Agg_By_Cycle:
  - sum_scale_profit = SUM(close_profit for SCALE_OUT)
  - close_profit = close_profit for CLOSE
  - pnl_expected = sum_scale_profit + close_profit
  - sum_scale_volume = SUM(close_volume for SCALE_OUT)
  - close_volume = close_volume for CLOSE
  - vol_expected = sum_scale_volume + close_volume
- Compare against Cycle Summary:
  - pnl_mismatch = Cycle[pnl] <> Agg[pnl_expected]
  - vol_mismatch = Cycle[close_volume] <> Agg[vol_expected]

## D) Reporting layout
1) Data Quality Summary: cards + bar chart by failure code
2) Failure Details: table (code, key, expected, actual, notes)
3) Reconciliation Diagnostics: cycle-level page

## E) Export
Export DQ_Summary and DQ_Details per run.
