#!/usr/bin/env python3
# Phase 6 - Data Quality Checks Runner (pandas)
#
# Reads:
#   *_MM_Snapshots.csv
#   *_MM_Events.csv
#   *_MM_Cycle_Summary.csv
# Produces:
#   dq_summary.csv (counts by code + severity)
#   dq_details.csv (row-level details per finding)
#
# TEMPLATE: adjust delimiter/encoding and column names if needed.

import pandas as pd
from dataclasses import dataclass

@dataclass
class Finding:
    code: str
    severity: str
    key_type: str
    key_value: str
    message: str
    expected: str = ""
    actual: str = ""


def load_csv(path: str) -> pd.DataFrame:
    # Adjust delimiter/encoding if needed
    return pd.read_csv(path)


def run_checks(snap: pd.DataFrame, ev: pd.DataFrame, cy: pd.DataFrame):
    findings = []

    # Snapshot pairing (correlation_id)
    if 'record_type' in snap.columns and 'correlation_id' in snap.columns:
        grp = snap.groupby('correlation_id')['record_type'].value_counts().unstack(fill_value=0)
        before = grp.get('MM_SNAPSHOT_BEFORE', pd.Series(0, index=grp.index))
        after  = grp.get('MM_SNAPSHOT_AFTER',  pd.Series(0, index=grp.index))

        for cid in grp.index[(before == 1) & (after == 0)]:
            findings.append(Finding('JF-SNAP-01','FATAL','correlation_id',str(cid),'Missing AFTER snapshot','1 AFTER','0 AFTER'))

        for cid in grp.index[(before == 0) & (after == 1)]:
            findings.append(Finding('JF-SNAP-02','FATAL','correlation_id',str(cid),'Missing BEFORE snapshot','1 BEFORE','0 BEFORE'))

        for cid in grp.index[(before != 1) | (after != 1)]:
            if ((before == 1) & (after == 1)).loc[cid]:
                continue
            findings.append(Finding('JF-SNAP-03','ERROR','correlation_id',str(cid),'Duplicate/misaligned snapshot pair','1 BEFORE & 1 AFTER',f"{before.loc[cid]} BEFORE, {after.loc[cid]} AFTER"))

    # BEFORE outcome neutrality
    outcome_cols = ['action_executed','execution_reason','previous_stoploss','new_stoploss','closed_lots','event_outcome']
    if set(['record_type','correlation_id', *outcome_cols]).issubset(snap.columns):
        before_rows = snap[snap['record_type'] == 'MM_SNAPSHOT_BEFORE']
        viol = before_rows[
            (before_rows['action_executed'] != False) |
            (before_rows['execution_reason'].fillna('') != '') |
            (before_rows['previous_stoploss'].fillna(0) != 0) |
            (before_rows['new_stoploss'].fillna(0) != 0) |
            (before_rows['closed_lots'].fillna(0) != 0) |
            (before_rows['event_outcome'].fillna('') != '')
        ]
        for _, r in viol.iterrows():
            findings.append(Finding('JF-SNAP-04','ERROR','correlation_id',str(r['correlation_id']),'BEFORE outcome fields not neutral'))

    # AFTER outcome validity / missing reason
    if set(['record_type','correlation_id','action_executed','execution_reason','event_outcome']).issubset(snap.columns):
        after_rows = snap[snap['record_type'] == 'MM_SNAPSHOT_AFTER']
        valid = {'SUCCESS','FAIL','SKIP'}
        bad_outcome = after_rows[~after_rows['event_outcome'].fillna('').isin(valid)]
        for _, r in bad_outcome.iterrows():
            findings.append(Finding('JF-SNAP-05','ERROR','correlation_id',str(r['correlation_id']),'AFTER event_outcome invalid','SUCCESS/FAIL/SKIP',str(r['event_outcome'])))

        missing_reason = after_rows[(after_rows['action_executed'] == False) & (after_rows['execution_reason'].fillna('') == '')]
        for _, r in missing_reason.iterrows():
            findings.append(Finding('JF-SNAP-05','ERROR','correlation_id',str(r['correlation_id']),'AFTER execution_reason missing when action_executed=false'))

    # Cycle CLOSE cardinality and summary presence
    if set(['cycle_id','event_type']).issubset(ev.columns):
        close = ev[ev['event_type'] == 'MM_EVENT_CLOSE']
        cc = close.groupby('cycle_id').size()

        for cid, n in cc[cc != 1].items():
            findings.append(Finding('JF-CYCLE-03','FATAL','cycle_id',str(cid),'Event CLOSE count not equal to 1','1',str(n)))

        if 'cycle_id' in cy.columns:
            cy_ids = set(cy['cycle_id'].astype(str))
            for cid in set(close['cycle_id'].astype(str)) - cy_ids:
                findings.append(Finding('JF-CYCLE-02','FATAL','cycle_id',cid,'Event CLOSE exists but Cycle Summary missing'))

            close_ids = set(close['cycle_id'].astype(str))
            for cid in set(cy['cycle_id'].astype(str)) - close_ids:
                findings.append(Finding('JF-CYCLE-01','FATAL','cycle_id',cid,'Cycle Summary exists but Event CLOSE missing'))

    # Cycle Summary evidence reconciliation + pnl/volume aggregation
    needed_ev = {'cycle_id','event_type','ticket','position_type','event_time','close_price','close_reason','close_volume','deal_id','close_profit'}
    needed_cy = {'cycle_id','ticket','position_type','exit_time','exit_price','close_reason','close_volume','deal_id','pnl'}
    if needed_ev.issubset(ev.columns) and needed_cy.issubset(cy.columns):
        close = ev[ev['event_type'] == 'MM_EVENT_CLOSE'][list(needed_ev - {'event_type'})].copy()
        close = close.rename(columns={
            'event_time':'ev_exit_time',
            'close_price':'ev_exit_price',
            'deal_id':'ev_deal_id',
            'close_reason':'ev_close_reason',
            'close_volume':'ev_close_volume',
            'close_profit':'ev_close_profit'
        })
        merged = cy.merge(close, on='cycle_id', how='left')

        def mismatch(col_cy, col_ev, label):
            mm = merged[merged[col_cy] != merged[col_ev]]
            for _, r in mm.iterrows():
                findings.append(Finding('JF-CYCLE-04','ERROR','cycle_id',str(r['cycle_id']),f"{label} mismatch",str(r[col_ev]),str(r[col_cy])))

        mismatch('exit_time','ev_exit_time','exit_time')
        mismatch('exit_price','ev_exit_price','exit_price')
        mismatch('close_reason','ev_close_reason','close_reason')
        mismatch('deal_id','ev_deal_id','deal_id')
        mismatch('ticket','ticket','ticket')
        mismatch('position_type','position_type','position_type')

        scale = ev[ev['event_type'] == 'MM_EVENT_SCALE_OUT'].copy()
        scale_profit = scale.groupby('cycle_id')['close_profit'].sum(min_count=1).fillna(0)
        scale_vol = scale.groupby('cycle_id')['close_volume'].sum(min_count=1).fillna(0)

        merged = merged.set_index('cycle_id')
        expected_pnl = scale_profit.reindex(merged.index).fillna(0) + merged['ev_close_profit'].fillna(0)
        expected_vol = scale_vol.reindex(merged.index).fillna(0) + merged['ev_close_volume'].fillna(0)

        pnl_mm = merged[merged['pnl'] != expected_pnl]
        for cid, r in pnl_mm.iterrows():
            findings.append(Finding('JF-CYCLE-05','FATAL','cycle_id',str(cid),'pnl aggregation mismatch',str(expected_pnl.loc[cid]),str(r['pnl'])))

        vol_mm = merged[merged['close_volume'] != expected_vol]
        for cid, r in vol_mm.iterrows():
            findings.append(Finding('JF-CYCLE-06','FATAL','cycle_id',str(cid),'close_volume aggregation mismatch',str(expected_vol.loc[cid]),str(r['close_volume'])))

    return findings


def to_outputs(findings, out_prefix='dq'):
    df = pd.DataFrame([f.__dict__ for f in findings])
    if df.empty:
        df = pd.DataFrame(columns=['code','severity','key_type','key_value','message','expected','actual'])

    summary = df.groupby(['code','severity']).size().reset_index(name='count')
    summary.to_csv(f'{out_prefix}_summary.csv', index=False)
    df.to_csv(f'{out_prefix}_details.csv', index=False)


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--snap', required=True, help='Path to *_MM_Snapshots.csv')
    ap.add_argument('--events', required=True, help='Path to *_MM_Events.csv')
    ap.add_argument('--cycle', required=True, help='Path to *_MM_Cycle_Summary.csv')
    ap.add_argument('--out', default='dq', help='Output file prefix')
    args = ap.parse_args()

    snap = load_csv(args.snap)
    ev = load_csv(args.events)
    cy = load_csv(args.cycle)

    findings = run_checks(snap, ev, cy)
    to_outputs(findings, args.out)
    print(f"Wrote {args.out}_summary.csv and {args.out}_details.csv")


if __name__ == '__main__':
    main()
