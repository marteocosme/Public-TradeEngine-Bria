# Phase 6 — Data Quality Runner Pack

Generated: 2026-05-19 (UTC+8)

## Included files
1) PHASE-6_Data_Quality_Checks_Checklist.md
2) PHASE-6_Checklist_Runner_Excel_PowerBI.md
3) phase6_dq_runner.py

## Quick start (Python)
python3 phase6_dq_runner.py --snap <Base>_MM_Snapshots.csv --events <Base>_MM_Events.csv --cycle <Base>_MM_Cycle_Summary.csv --out dq

Outputs:
- dq_summary.csv
- dq_details.csv

## Notes
- Adjust delimiters/encoding if your CSV is not default comma/utf-8.
- This template assumes headers match SSOT names.
